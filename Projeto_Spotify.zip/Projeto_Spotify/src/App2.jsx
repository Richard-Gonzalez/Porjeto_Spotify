import React from 'react'

const App2 = () => {
  return (
    <div>App2</div>
  )
}

export default App2;